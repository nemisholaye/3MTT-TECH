 //Get access to the button
 const button = document.querySelector('button');

 //Add event listener to the button
 button.addEventListener('click', showMyName);

 //Function to show my name
 function showMyName() {
     alert('My name is Yemi');
 }