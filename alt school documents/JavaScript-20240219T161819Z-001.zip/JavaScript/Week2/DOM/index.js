// Display the title of the current page
// alert(document.title);

// Display the content of the head tag
// alert(document.head.innerHTML);

// Display the content of the body tag
// alert(document.body.innerHTML);


//Task ==> Interact with DOM elements using the Developer Tools
// E.g Wikipedia, Google, Twitter



